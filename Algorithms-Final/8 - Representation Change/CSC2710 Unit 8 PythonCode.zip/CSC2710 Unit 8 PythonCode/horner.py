# Input: P is an array storing the coefficients
#    of the polynomial
# Output: The value of the polynomial evaluated at x
def HornerEvaluate( P, x ):
    p = P[ len(P) - 1 ]
    for i in range( len(P)-1, -1, -1 ):
        p = x * p + P[ i ]
    return p



P = [ 5, 2, 23, 0, 0, 1 ]
print( HornerEvaluate(P, 4) )
print( HornerEvaluate(P, 3) )
