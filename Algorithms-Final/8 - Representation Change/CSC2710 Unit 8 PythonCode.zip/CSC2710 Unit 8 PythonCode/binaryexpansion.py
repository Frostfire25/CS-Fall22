# Input: A number x and the array B of size lg(n)
#   which holds the binary expansion of the exponent n
#   It's highest digit is 1
# Output: The value x^n
def LeftRightBinaryExpansion( B, x ):
    prod = x
    # Start at the floor of the lg of n, which is
    #   the same as len(B)-2 (when the highest digit
    #   of B is guaranteed to be a 1)
    for i in range( len(B)-2, -1, -1 ):
        prod = prod * prod
        if( B[i] == 1 ):
            prod = prod * x
    return prod


B = [ 0, 1, 1 ]
x = 4
print( LeftRightBinaryExpansion( B, x ) )
