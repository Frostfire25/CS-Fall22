import math

# Input: Array H is an array of orderable objects and i >= 1
# Output: The subtree rooted at H[i] is a heap
def Heapify( H, i ):
    k = i
    v = H[k]     # Keep the original element
    heap = False # Is it currently a heap?
    # While we haven't created a heap yet
    while( heap == False and 2*k < len(H) ):
        # Jump to the child of the current node
        j = 2 * k
        if( j < len(H) ):
            # Check the other child
            if( H[j] < H[j+1]):
                j = j + 1
        # Is the tree rooted at v a heap?
        if( v >= H[j] ):
            heap = True
        # Otherwise, put larger child into parent position
        else:
            H[k] = H[j]
            k = j
    # Place the original key at the correct location
    H[k] = v

# Input: An array H of integers
# Output: A heap H
def HeapBottomUp( H ):
    for i in range( math.floor(len(H)/2), -1, -1 ):
        Heapify( H, i )


H = [ 4, 1, 6, 4, 7, 4, 3, 6, 8, 2 ]
print(H)
HeapBottomUp( H )
print(H)


