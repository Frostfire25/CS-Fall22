# Input: n is an integer
# Output: The nth Fibonacci number
def Fibonacci( n ):
    if( n == 1 or n == 2 ):
        return 1
    return Fibonacci( n - 1 ) + Fibonacci( n - 2 )


global memo
memo = [ None for x in range( 100 ) ]
# Input: n >= 1
# Output: The nth Fibonacci number
def FibonacciMomoized( n ):
    global memo
    if memo[ n - 1 ] != None:
        return memo[ n - 1 ]
    if( n <= 2 ):
        v = 1
    else:
        v = FibonacciMomoized( n - 1 ) + FibonacciMomoized( n - 2 )
    memo[ n - 1 ] = v
    return v

print( FibonacciMomoized( 8 ) )
print( FibonacciMomoized( 6 ) )


# Coin row problem
# Input: i and j are indices into C, a 2D array of integers
# Output: 
def CoinCollect( i, j, C ):
    global memo
    if( i == 0 and j == 0 ):
        memo = [ [ None for x in range(len(C)) ] for y in range(len(C[0])) ]
    n = len(C)
    m = len( C[i] )
    if( memo[i][j]!= None ):
        v = memo[i][j]
    elif( 1 <= i and i <= n and 1 <= j and j <= m ):
        v = max( CoinCollect(i-1, j, C), CoinCollect(i, j-1, C) + C[i][j] )
    elif( i == 0 and i <= j and j <= m ):
        v = 0
    elif( j == 0 and 1 <= i and i <= n ):
        v = 0
    memo[i][j] = v
    return v


# Rod Cutting Problem
memo = [ None for x in range(10000) ] # infinity
# Input: An array p representing the rod, n is its length
# Output: The maximum possible revenue from cutting the rod
def CutRod( p, n ):
    if(memo[n] != None ):
        v = memo[n]
    elif( n == 0 ):
        v = 0
    else:
        v = -100000 # negative infinity
        # Find the maximum revenue for each possible cut
        for i in range( n ):
            v = max( v, p[i] + CutRod(p, n-i) )
    memo[n] = v
    return v


# Longest Increasing Subsequence
memo = [ None for x in range(10000) ] # infinity
# Input: A sequence S of length n, the current index from which
#   we are measuring the increasing sequence
# Output: The length of the longest increasing subsequence of S
def LIS( S, i ):
    if( memo[i] != None ):
        v = memo[i]
    elif( i == 1 ):
        v = 1
    else:
        v = -100000 #-infinity
        for j in range( i ):
            if( S[j] <= S[i] ):
                v = max( v, 1 + LIS(S, j) )
        # if v is still -infinity
        if( v == -100000 ):
            v = 1
    memo[i] = v
    return v


# Non-recursive memoized algorithms
def FibonacciMomoizedNonRec( n ):
    F = [ None for x in range(n) ]
    for i in range(1,n):
        if( i <= 2 ):
            F[i] = i
        else:
            F[i] = F[i-1] + F[i-2]
    return F[n]


#Non-recursive memoized rod cutting
def CutRodNonRec( p ):
    n = len(p)
    r = [ None for x in range(n) ]
    for j in range(1, n):
        v = -100000 #-infinity
        for i in range( 1, j ):
            v = max( v, p[i] + r[j-i] )
        r[j] = v
    return r[n]


















