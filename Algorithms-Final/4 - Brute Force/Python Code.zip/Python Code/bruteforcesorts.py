# Input: An array A and two indices to swap, x and y
# Output: A's values at x and y are swapped
def Swap(A, x, y):
    n = A[x]
    A[x] = A[y]
    A[y] = n

# Input: An array A of integers
# Output: A is in sorted order
def SelectionSort( A ):
    for i in range( len(A) - 1 ):
        m = i
        # Find the smallest element from element i to the end
        for j in range( i+1, len(A) ):
            if( A[j] < A[m] ):
                m = j
        Swap( A, i, m )

# Input: An array A of integers
# Output: A is in sorted order
def BubbleSort( A ):
    for i in range( len(A) - 1 ):
        for j in range( len(A)- 1 - i ):
            if( A[j+1] < A[j] ):
                Swap( A, j, j+1 )

A = [ 3, 1, 5, 4, 8, 3, 7, 4, 5, 2, 3, 5, 1 ]
#SelectionSort( A )
BubbleSort( A )
print( A ) 
