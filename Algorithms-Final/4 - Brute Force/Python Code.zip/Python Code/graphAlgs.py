# Code from:
#   https://www.bogotobogo.com/python/python_graph_data_structures.php

class Vertex:
    def __init__(self, node):
        self.id = node
        self.adjacent = {}

    def __str__(self):
        return str(self.id) + ' adjacent: ' + str([x.id for x in self.adjacent])

    def add_neighbor(self, neighbor, weight=0):
        self.adjacent[neighbor] = weight

    def get_connections(self):
        return self.adjacent.keys()  

    def get_id(self):
        return self.id

    def get_weight(self, neighbor):
        return self.adjacent[neighbor]

class Graph:
    def __init__(self):
        self.vert_dict = {}
        self.num_vertices = 0

    def __iter__(self):
        return iter(self.vert_dict.values())

    def add_vertex(self, node):
        self.num_vertices = self.num_vertices + 1
        new_vertex = Vertex(node)
        self.vert_dict[node] = new_vertex
        return new_vertex

    def get_vertex(self, n):
        if n in self.vert_dict:
            return self.vert_dict[n]
        else:
            return None

    def add_edge(self, frm, to, cost = 0):
        if frm not in self.vert_dict:
            self.add_vertex(frm)
        if to not in self.vert_dict:
            self.add_vertex(to)

        self.vert_dict[frm].add_neighbor(self.vert_dict[to], cost)
        self.vert_dict[to].add_neighbor(self.vert_dict[frm], cost)

    def get_vertices(self):
        return self.vert_dict.keys()

g = Graph()

g.add_vertex('a')
g.add_vertex('b')
g.add_vertex('c')
g.add_vertex('d')
g.add_vertex('e')
g.add_vertex('f')
 
g.add_edge('a', 'c')
g.add_edge('a', 'f')
g.add_edge('b', 'c')
g.add_edge('b', 'd')
g.add_edge('c', 'd')
g.add_edge('e', 'f')

for v in g:
    for w in v.get_connections():
        vid = v.get_id()
        wid = w.get_id()
        print( '( %s , %s, %3d)'  % ( vid, wid, v.get_weight(w)))

for v in g:
    print ('g.vert_dict[%s]=%s' %(v.get_id(), g.vert_dict[v.get_id()]))


# Input: A Graph G=(E,V) and a count (global)
# Output: A graph G'=(E',V') where E' = E and V'=V with its
#   verticies marked with consecutive integers in the order that
#   the vertices were first encountered
def DFS( G ):
    global count
    count = 0
    # Mark every vertex in V with a 0
    for v in G:
        v.visited = 0
    for v in G:
        if( v.visited == 0 ):
            DFS_Visit(v)


# Input: v is an unvisited vertex
# Output: All descendants of v are visited
def DFS_Visit( v ):
    global count
    count = count + 1
    v.visited = count
    for u in v.get_connections():
        if( u.visited == 0 ):
            DFS_Visit( u )

# Input: A Graph G=(E,V) and a count (global)
# Output: A graph G'=(E',V') where E' = E and V'=V with its
#   verticies marked with consecutive integers in the order that
#   the vertices were first encountered
def BFS( G ):
    global count
    count = 0
    # Mark every vertex in V with a 0
    for v in G:
        v.visited = 0
    # Visit each vertex
    for v in G:
        if(v.visited == 0 ):
            BFS_Visit( v )

# Input: v is an unvisited vertex
# Output: All descendants of v are visited
def BFS_Visit( v ):
    global count
    count = count + 1
    v.visited = count
    # Create a Queue, enqueueing the vertex
    Q = [v]
    # While there are still elements in the queue, 
    while( len(Q) > 0 ):
        for u in v.get_connections():
            if( u.visited == 0 ):
                count = count + 1
                u.visited = count
                Q.append(u)
        Q.pop(0) # Dequeue the first element

BFS( g )
for v in g:
    print( v.id, "  ", v.visited )
