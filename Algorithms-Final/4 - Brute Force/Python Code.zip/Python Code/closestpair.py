import math

# Input: Two 2D points
# Output: The euclidean distance between the points
def distance( A, B ):
    return math.sqrt( (A[0] - B[0])**2 + (A[1] - B[1])**2 )


# Input: P is the list of n >= 2 points in XY space
# Output: The distance between the two closest points
def ClosestPair( P ):
    d = 10000000 # Basically, infinity
    for i in range( len(P) - 1 ):
        for j in range( i + 1, len(P) ):
            d = min(d, distance( P[i], P[j] ) )
    return d

P = [ [4, 2], [3, 4], [1, 5], [5, 4], [3, 3], [2, 4] ]
print( ClosestPair( P ) )
