# Input: An array A of comparable objects
# Output: An arry S of A`s elements in sorted order
def ComparisonCountingSort( A ):
    # Initialize an array to hold the counts
    C = [ 0 for x in range( len(A) ) ]
    S = [ 0 for x in range( len(A) ) ]
    # Count the frequency of each element
    for i in range( len(A)-1 ):
        for j in range( i+1, len(A) ):
            if( A[i] < A[j] ):
                C[j] = C[j] + 1
            else:
                C[i] = C[i] + 1
    # Place the elements in their final location
    for i in range( len(A) ):
        S[ C[i] ] = A[i]
    return S

# Input: An array A of comparable objects, upper and lower
#   are the upper and lower bounds of the elements of A
# Output: An array S of A`s elements sorted
def CountingSort( A, upper, lower ):
    # Initialize the elements frequencies to 0
    F = [ 0 for x in range( upper-lower+1 ) ]
    S = [ 0 for x in range( len(A) ) ]
    # Compute the frequencies of the elements of A
    for j in range( len(A) ):
        F[ A[j] - lower ] = F[ A[j] - lower ] + 1
 
    # Compute the distribution
    for j in range( 1, upper-lower+1  ):
        F[j] = F[ j-1 ] + F[j]

    # Place the elements of A into S in sorted order
    for i in range( len(A)-1, -1, -1 ):
        j = A[i] - lower
        S[ F[j] - 1 ] = A[i]
        F[j] = F[j] - 1
    return S


A = [ 5,6,3,2,8,5,9,4,5,7,6,1,2,4,1,4,3,5,7,4,3 ]
print(CountingSort( A, 9, 1 ))
