# Input: A search string S and an alphabet of possible characters E
# Output: A table T indexed by alphabet characters and filled with
#   appropriately computed shift sizes
def BuildShiftTable(S, E):
    # Initialize T as a Dictionary
    T = {}
    # Initialize every character a complete shift
    for x in range(len(E)):
        T[ E[x] ] = 0

    # Set the shift distance of each character in S to the distance
    #   from the right most occurrence to the end of the pattern
    for i in range( len(S) - 1 ):
        T[ S[i] ] = len(S) - 1 - i
    return T

# Input: A patter P and a text T
# Output: The index of the left end of the first substring of T
#    that matches P, or -1
def Horspool( P, T ):
    # Build the shift table for the pattern
    S = BuildShiftTable(P, E)

    # Start at the end of the pattern
    i = len(P) - 1
    while( i <= len(T)-1 ):
        k = 0
        # Match all of the characters possible
        while( k <= len(T) - 1 and P[len(P)-1-k] == T[i-k] ):
            k = k + 1
        # Now check to see if we matched the whole pattern
        if( k == len(P) ):
            return i - len(P) + 1
        # If nothing matched, shift appropriately
        else:
            i = i + S[ T[i] ]
    return -1
