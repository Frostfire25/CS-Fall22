import math

# Input: Sorted arrays B[0 .. p-1] and C[0 .. q-1],
#    and a destination array A of size p + q
# Output: Sorted array A[0 .. p+q-1] of the elements of B and C
def Merge( A, B, C ):
    i = 0
    j = 0
    k = 0
    p = len(B)
    q = len(C)
    # Interleave the two subarrays
    while( i < p and j < q ):
        if( B[i] <= C[j] ):
            A[k] = B[i]
            i = i + 1
        else:
            A[k] = C[j]
            j = j + 1
        k = k + 1
    # Copy the remaining elements into the final array
    while( i < p ):
        A[k] = B[i]
        k = k+1
        i = i+1
    while( j < q ):
        A[k] = C[j]
        k = k+1
        j = j+1

# Input: An array A of integers
# Output: A is in sorted order
def MergeSort(A):
    if( len(A) > 1 ):
        # Divide A in half
        B = A[0 : (math.floor(len(A)/2))].copy()
        C = A[math.floor(len(A)/2) : len(A)].copy()
        MergeSort( B )
        MergeSort( C )
        Merge( A, B, C )

# Input: A subarray A[left .. right] of A and an integer k
#    such that 1 <= k <= right - left + 1
# Output: The value of the k-th smallest element in A[left .. right]
def QuickSelect( A, left, right, k ):
    s = LumotoPartition(A, left, right)
    if( s == k-1 ):
        return A[s]
    elif( s > left + k - 1):
        return QuickSelect( A, left, s-1, k )
    else:
        return QuickSelect( A, s+1, right, k )

# Input: An array A and two indices to swap, x and y
# Output: A's values at x and y are swapped
def Swap(A, x, y):
    n = A[x]
    A[x] = A[y]
    A[y] = n

# Input: A subarray A[l..r] 
# Output: Partition of A[l..r] and the new position of the pivot
def LumotoPartition(A, left, right):
    p = A[left]
    s = left
    for i in range(left+1, right+1):
        if( A[i] < p ):
            s = s + 1
            Swap(A, s, i)
    Swap(A, left, s)
    return s


# Input: An array A, defined by left and right indices
# Output: A is in sorted increasing order
def QuickSort(A, left, right):
    # If our pointers haven't met yet
    if( left < right ):
        # Partition the array
        s = LumotoPartition(A, left, right)
        # Sort the lower half, then the upper half
        QuickSort( A, left, s - 1 )
        QuickSort( A, s + 1, right )
              
A = [ 9, 4, 5, 2, 3, 7, 1, 3, 4, 3, 6]
QuickSort(A, 0, len(A) - 1)
print(A)



















