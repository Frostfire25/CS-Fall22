import math

# Input: Sorted arrays B[0 .. p-1] and C[0 .. q-1],
#    and a destination array A of size p + q
# Output: Sorted array A[0 .. p+q-1] of the elements of B and C
def Merge( A, B, C ):
    i = 0
    j = 0
    k = 0
    p = len(B)
    q = len(C)
    # Interleave the two subarrays
    while( i < p and j < q ):
        if( B[i] <= C[j] ):
            A[k] = B[i]
            i = i + 1
        else:
            A[k] = C[j]
            j = j + 1
        k = k + 1
    # Copy the remaining elements into the final array
    while( i < p ):
        A[k] = B[i]
        k = k+1
        i = i+1
    while( j < q ):
        A[k] = C[j]
        k = k+1
        j = j+1

# Input: An array A of integers
# Output: A is in sorted order
def MergeSort(A):
    if( len(A) > 1 ):
        # Divide A in half
        B = A[0 : (math.floor(len(A)/2))].copy()
        C = A[math.floor(len(A)/2) : len(A)].copy()
        MergeSort( B )
        MergeSort( C )
        Merge( A, B, C )


# Input: Array A of integers in sorted increasing order
# Output: True is returned if the array consists only of unique
#    elements, False otherwise
def IsUnique( A ):
    for i in range (len(A) - 1):
        if( A[i] == A[i+1] ):
            return False
    return True

# Input: A is a sorted array of integers
# Output: The mode of A
def FindMode( A ):
    i = 0
    mfreq = 1       # The current mode's frequency
    mode = A[0]     # The current mode
    while( i < len(A) ):
        rlen = 1    # The length of the current run
        rval = A[i] # The value of the current run
        while( i + rlen < len(A) and A[i + rlen] == rval):
            rlen = rlen + 1  # Increase the count of the run
            # If it's a longer run, update the current mode
            if( rlen > mfreq ):
                mfreq = rlen
                mode = rval
        i = i + rlen
    return mode
              
A = [ 9, 4, 5, 2, 3, 7, 1, 3, 4, 3, 6]
MergeSort(A)
print(IsUnique(A))
print( FindMode(A) )



















